angular.module('starter.controllers', [])

.controller('AppController', function ($scope, $http) {


    $scope.desc = "Website of Henry Mascot, Serial Tech Enterpreneur and Maximum Impact Evangelist aka #executionMafia";

})